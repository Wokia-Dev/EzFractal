class EzComponent:
    def __init__(self, name: str, x: int, y: int, width: int = 0, height: int = 0):
        self.name = name
        self.x = x
        self.y = y
        self.width = width
        self.height = height
